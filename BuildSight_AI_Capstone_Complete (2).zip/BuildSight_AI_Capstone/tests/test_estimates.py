import unittest

def estimate(area, construction_rate, completion_percent, market_rate):
    if area <= 0:
        raise ValueError("area must be positive")
    if not 0 <= completion_percent <= 100:
        raise ValueError("completion must be between 0 and 100")
    total = area * construction_rate
    return {
        "total": round(total),
        "incurred": round(total * completion_percent / 100),
        "market": round(area * market_rate),
        "contingency": round(total * 0.10),
    }

class EstimateTests(unittest.TestCase):
    def test_standard_estimate(self):
        result = estimate(2500, 2200, 35, 6500)
        self.assertEqual(result["total"], 5_500_000)
        self.assertEqual(result["incurred"], 1_925_000)
        self.assertEqual(result["market"], 16_250_000)
        self.assertEqual(result["contingency"], 550_000)

    def test_zero_completion(self):
        self.assertEqual(estimate(100, 1000, 0, 2000)["incurred"], 0)

    def test_full_completion(self):
        self.assertEqual(estimate(100, 1000, 100, 2000)["incurred"], 100_000)

    def test_invalid_area(self):
        with self.assertRaises(ValueError):
            estimate(0, 1000, 50, 2000)

    def test_invalid_completion(self):
        with self.assertRaises(ValueError):
            estimate(100, 1000, 101, 2000)

if __name__ == "__main__":
    unittest.main()
